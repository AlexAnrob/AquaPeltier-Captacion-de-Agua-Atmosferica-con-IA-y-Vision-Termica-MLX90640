import time
import board
import busio
import numpy as np
import adafruit_mlx90640
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
import RPi.GPIO as GPIO
import threading
import datetime

# === CONFIGURACIÓN DEL SERVO ===
SERVO_PIN = 18
GPIO.setmode(GPIO.BCM)
GPIO.setup(SERVO_PIN, GPIO.OUT)
pwm = GPIO.PWM(SERVO_PIN, 50)  # Frecuencia típica para servos: 50 Hz
pwm.start(0)

STEP_DURATION = 0.25  # Tiempo estimado para girar ~45°
DUTY_CW = 2.5         # Ajusta según tu servo
DUTY_CCW = 7.5        # Ajusta según tu servo
DELAY = 10            # segundos entre pasos

# === FUNCIONES DE SERVO ===
def rotate(direction, duration):
    if direction == 'cw':
        pwm.ChangeDutyCycle(DUTY_CW)
    elif direction == 'ccw':
        pwm.ChangeDutyCycle(DUTY_CCW)
    time.sleep(duration)
    pwm.ChangeDutyCycle(0)
    time.sleep(0.5)  # Pausa para asegurar que el servo se detenga

# === FUNCIONES DE CÁMARA TÉRMICA ===
def initialize_sensor():
    i2c = busio.I2C(board.SCL, board.SDA)
    mlx = adafruit_mlx90640.MLX90640(i2c)
    mlx.refresh_rate = adafruit_mlx90640.RefreshRate.REFRESH_2_HZ
    return mlx

def setup_plot():
    fig, ax = plt.subplots(figsize=(12, 7))
    therm1 = ax.imshow(np.zeros((24, 32)), vmin=0, vmax=60, cmap='jet', interpolation='bilinear')
    cbar = fig.colorbar(therm1)
    cbar.set_label('Temperature [°C]', fontsize=14)
    plt.title('Thermal Image')
    return fig, ax, therm1

def update_display(canvas, therm1, data_array):
    therm1.set_data(np.fliplr(data_array))
    therm1.set_clim(vmin=np.min(data_array), vmax=np.max(data_array))
    canvas.draw()

def save_image(fig):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"{timestamp}.png"
    fig.savefig(filename)
    print(f"Imagen guardada: {filename}")

# === FLUJO PRINCIPAL ===
def run_sequence():
    mlx = initialize_sensor()
    fig, ax, therm1 = setup_plot()

    root = tk.Tk()
    root.wm_title("Thermal Camera")
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas_widget = canvas.get_tk_widget()
    canvas_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=1)

    frame = np.zeros((24*32,))

    def update_loop():
        try:
            mlx.getFrame(frame)
            data_array = np.reshape(frame, (24, 32))
            update_display(canvas, therm1, data_array)
        except Exception as e:
            print(f"Error en captura continua: {e}")
        root.after(1000, update_loop)

    update_loop()

    def movimiento_servo_infinito():
        while True:
            posiciones = [
                ("Giro a ~45°", 'cw', STEP_DURATION, True),
                ("Giro a ~135°", 'cw', STEP_DURATION * 2, True),
                ("Giro a ~225°", 'cw', STEP_DURATION * 2, True),
                ("Giro a ~315°", 'cw', STEP_DURATION * 2, True),
                ("Regreso a ~0°", 'ccw', STEP_DURATION * 7, False)  # No capturar imagen
            ]

            for mensaje, direccion, duracion, capturar in posiciones:
                print(mensaje)
                rotate(direccion, duracion)
                time.sleep(4)
                if capturar:
                    save_image(fig)
                time.sleep(DELAY)

    threading.Thread(target=movimiento_servo_infinito, daemon=True).start()

    root.mainloop()

if __name__ == '__main__':
    try:
        run_sequence()
    finally:
        pwm.stop()
        GPIO.cleanup()
